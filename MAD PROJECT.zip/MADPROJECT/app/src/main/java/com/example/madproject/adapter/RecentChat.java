package com.example.madproject.adapter;

public class RecentChat {
}
